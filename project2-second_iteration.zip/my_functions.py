import matplotlib.pyplot as plt
import torch
import numpy as np
from torch import nn, optim, tensor
import torch.nn.functional as F
import torchvision
from torchvision import datasets, transforms, models
import json
import PIL
from PIL import Image
"""
These are the main functions which will be called from the train and predict scripts.
This will stimulate better management & udnerstanding of algorithmn flow.
"""
arch = {'vgg16' : 25088,
        'alexnet' : 9216}

def load_data(aqui = "flowers"):
    data_dir = aqui
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
    train_transforms = transforms.Compose([transforms.RandomRotation(20),
				     transforms.RandomResizedCrop(224),
				     transforms.RandomHorizontalFlip(),
				     transforms.ToTensor(),
				     transforms.Normalize([0.485, 0.456, 0.406],
							 [0.229, 0.224, 0.225])])
    valid_transforms = transforms.Compose([transforms.RandomResizedCrop(224),
				     transforms.ToTensor(),
				     transforms.Normalize([0.485, 0.456, 0.406],
							 [0.229, 0.224, 0.225])])
    test_transforms = transforms.Compose([transforms.RandomResizedCrop(224),
				     transforms.ToTensor(),
				     transforms.Normalize([0.485, 0.456, 0.406],
							 [0.229, 0.224, 0.225])])
    train_data = datasets.ImageFolder(train_dir, transform = train_transforms)
    valid_data = datasets.ImageFolder(valid_dir, transform = valid_transforms)
    test_data = datasets.ImageFolder(test_dir, transform = test_transforms)
    # DONE TODO: Using the image datasets and the trainforms, define the dataloaders
    trainloader = torch.utils.data.DataLoader(train_data, batch_size=64, shuffle=True)
    validloader = torch.utils.data.DataLoader(valid_data, batch_size=64)
    testloader = torch.utils.data.DataLoader(test_data, batch_size=64)
    image_datasets = [train_data, valid_data, test_data]
    dataloaders = [trainloader, validloader, testloader]
    return image_datasets, dataloaders
        
def train_nn(architecture, first_layer, learning_rate, my_epochs, process, loaderTrain, loaderTest):
	if architecture == 'vgg16':
	    model = models.vgg16(pretrained=True)
	elif architecture == 'alexnet':
	    model = models.alexnet(pretrained=True)
	else:
	    print('\nOnly vgg16 and alexnet are supported.')
	device = torch.device("cuda" if (torch.cuda.is_available() and process == 'gpu') else "cpu")
	for param in model.parameters():
		param.requires_grad = False
	model.classifier = nn.Sequential(nn.Linear(arch[architecture], first_layer),
					 nn.ReLU(),
					 nn.Dropout(0.2),
					 nn.Linear(first_layer, 384),
					 nn.ReLU(),
					 nn.Dropout(0.2),
					 nn.Linear(384, 102),
					 nn.LogSoftmax(dim=1))
	criterion = nn.NLLLoss()
	optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate) #optimal lr=0.001
	model.to(device);
	print(device)
	epochs = my_epochs
	steps = 0
	running_loss = 0
	print_every = 5
	for epoch in range(epochs):
		for inputs, labels in loaderTrain:
			steps += 1
			inputs,labels = inputs.to(device), labels.to(device)     
			optimizer.zero_grad()        
			logps = model.forward(inputs)
			loss = criterion(logps, labels)
			loss.backward()
			optimizer.step()
			running_loss += loss.item()
			if steps % print_every == 0:
				test_loss = 0
				accuracy = 0
				model.eval()
				with torch.no_grad():
					for inputs, labels in loaderTrain:
						inputs, labels = inputs.to(device), labels.to(device)
						logps = model.forward(inputs)
						batch_loss = criterion(logps, labels)
						test_loss += batch_loss.item()
						ps = torch.exp(logps)
						top_p, top_class = ps.topk(1, dim=1)
						equals = top_class == labels.view(*top_class.shape)
						accuracy += torch.mean(equals.type(torch.FloatTensor)).item()
				print(f"Epoch {epoch+1}/{epochs}.. "
				f"Train loss: {running_loss/print_every:.3f}.. "
				f"Test loss: {test_loss/len(loaderTrain):.3f}.. "
				f"Test accuracy: {accuracy/len(loaderTrain):.3f}")
				running_loss = 0
				model.train()
    #evaluate model accuracy with validation data
	model.eval()
	accuracy = 0
	cudaP = torch.cuda.is_available()
	if cudaP and process == 'gpu':
	    model.cuda()
	else:
	    model.cpu()
	pass1 = 0
	for data in loaderTest:
		pass1 += 1
		images, labels = data   
		if cudaP == True:
			images, labels = images.cuda(), labels.cuda()
		output = model.forward(images)
		ps = torch.exp(output).data
		equal = labels.data == ps.max(1)[1]
		accuracy += equal.type_as(torch.FloatTensor()).mean()
	print("\nValidation accuracy: {:.4f}".format(accuracy/pass1))
	return model, optimizer, criterion
   
def save_checkpoint(path, architecture, first_layer, learning_rate, my_epochs):
	from torchvision import datasets, transforms, models
	image_datasets, dataloaders = load_data('flowers')
	if architecture == 'vgg16':
		model = models.vgg16(pretrained=True)
	elif architecture == 'alexnet':
		model = models.alexnet(pretrained=True)
	model.class_to_idx = image_datasets[0].class_to_idx
	model.classifier = nn.Sequential(nn.Linear(arch[architecture], first_layer),
				 nn.ReLU(),
				 nn.Dropout(0.2),
				 nn.Linear(first_layer, 384),
				 nn.ReLU(),
				 nn.Dropout(0.2),
				 nn.Linear(384, 102),
				 nn.LogSoftmax(dim=1))
	checkpoint = {'input_size': arch[architecture],
              'output_size': 102,
              'model_name': architecture,  
              'classifier': model.classifier,
              'learning_rate': learning_rate,
              'epochs': my_epochs,
              'state_dict': model.state_dict(),
              'class_to_idx': model.class_to_idx}
	torch.save(checkpoint, path)
 
def load_checkpoint(path='checkpoint.pth'):
	checkpoint = torch.load(path)
	model = getattr(torchvision.models, checkpoint['model_name'])(pretrained=True)
	model.classifier = checkpoint['classifier']
	model.epochs = checkpoint['epochs']
	model.class_to_idx = checkpoint['class_to_idx']
	model.load_state_dict(checkpoint['state_dict'])
	return model
        
def process_image(infile):
	image = Image.open(infile)
    #from Udacity questions/help files
	current_width, current_height = image.size
	if current_width < current_height:
		new_height = int(current_height * 256/ current_width)
		image = image.resize((256, new_height))
	else:
		new_width = int(current_width * 256/ current_height)
		image = image.resize((new_width, 256))
    #from https://stockoverflow.com/questions/16646183/crop-an-image-in-the-centre-using-pil#16648197
	precrop_width, precrop_height = image.size
	left = (precrop_width - 224)/2
	top = (precrop_height - 224)/2
	right = (precrop_width + 224)/2
	bottom = (precrop_height + 224)/2
	image = image.crop((left, top, right, bottom))
	np_image = np.array(image)
	np_image = np_image / np_image.max()
	mean = np.array([0.485, 0.456, 0.406])
	std = np.array([0.229, 0.224, 0.225])
	np_image = (np_image - mean) / std
	np_image = np_image.transpose((2, 0, 1))
	return np_image
        
def predict(image_path, model, topk=5, process):
	cudaP = torch.cuda.is_available()
	if cudaP and process = 'gpu':
		model.cuda()
	else:
		model.cpu()
	model.eval()
	image = process_image(image_path)
	image = torch.from_numpy(np.array([image])).float()
	if cudaP and process = 'gpu':
		image = image.cuda()
	output = model.forward(image)
	probs = torch.exp(output)
	prob = torch.topk(probs, topk)[0].tolist()[0]
	ind1 = torch.topk(probs, topk)[1].tolist()[0]
	indice = []
	for k in range(len(model.class_to_idx.items())):
		indice.append(list(model.class_to_idx.items())[k][0])
	classes = []
	for j in range(topk):
		classes.append(indice[ind1[j]])
	return prob, classes