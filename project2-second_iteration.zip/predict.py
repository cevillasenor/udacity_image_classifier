import matplotlib.pyplot as plt
import torch
import numpy as np
from torch import nn, optim, tensor
import torch.nn.functional as F
import torchvision
from torchvision import datasets, transforms, models
import json
import PIL
from PIL import Image
import argparse
import my_functions
"""
    This script loads a predefined NN from a checkpoint,
    then utilizes it to predict the closest class or group
    or classes to the classification of an input flower image.
    It outputs the classes names and probabilities and also
    allows for GPU or CPU processing alternative.
"""
parser = argparse.ArgumentParser()
parser.add_argument('--input_image', type = str, default = 'flowers/valid/44/image_01491.jpg')
parser.add_argument('--checkpoint', type = str, default = 'checkpoint.pth')
parser.add_argument('--topk', type = int, default = 5)
parser.add_argument('--gpu', type = str, default = 'gpu')
parser.add_argument('--category_names', type = str, default = 'cat_to_name.json')
reading = parser.parse_args()
image = reading.input_image
path = reading.checkpoint
top_classes = reading.topk
process = reading.gpu
categorias = reading.category_names           
with open(categorias, 'r') as json_file:
    cat_to_name = json.load(json_file)
image_datasets, dataloaders = my_functions.load_data()
model = my_functions.load_checkpoint(path)
probabilidades, clases = my_functions.predict(image, model, top_classes, process)
max_ind = np.argmax(probabilidades)
labels = []
for class1 in clases:
    labels.append(cat_to_name[class1])
print("\nThe closest prediction is {} with a probability of {:.3f}.\n".format(cat_to_name[clases[max_ind]], probabilidades[max_ind]))
for i in range(top_classes):
    print("{} with a probability of {:.3f}.".format(labels[i], probabilidades[i]))
print("\n")