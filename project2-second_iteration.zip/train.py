import matplotlib.pyplot as plt
import torch
import numpy as np
from torch import nn, optim, tensor
import torch.nn.functional as F
import torchvision
from torchvision import datasets, transforms, models
import json
import PIL
from PIL import Image
import argparse
import my_functions
""" 
    This script loads image data/transforms, then creates, trains, 
    and evaluates the nn. When done, it saves the checkpoint.    
"""
parser = argparse.ArgumentParser()
parser.add_argument('--image_dir', type = str, default = 'flowers', 
                    help = 'path to the folder of flower images') 
parser.add_argument('--arch', type = str, default = 'vgg16', 
                    help = 'architecture model used')
parser.add_argument('--hidden_units', type = int, default = 4096, 
                    help = 'number of units of first hidden layer')
parser.add_argument('--learning_rate', type = int, default = 0.001,
                    help = 'learning rate')
parser.add_argument('--epochs', type = int, default = 2,
                    help = 'epochs')
parser.add_argument('--gpu', type = str, default = 'gpu',
                    help = 'Use GPU for training')
parser.add_argument('--path', type = str, default = 'checkpoint.pth',
                    help = 'Path to checkpoint file')
parser.add_argument('--loaderTrain', type = str, default = 'trainloader',
                    help = 'Type of loader for training')
parser.add_argument('--loaderTest', type = str, default = 'testloader',
                    help = 'Type of loader for testing')

reading = parser.parse_args()
directoryF = reading.image_dir
architecture = reading.arch
first_layer = reading.hidden_units
lr = reading.learning_rate
epochs = reading.epochs
process = reading.gpu
path = reading.path
loaderTrain = reading.loaderTrain
loaderTest = reading.loaderTest

image_datasets, dataloaders = my_functions.load_data(directoryF)
loaderTrain = dataloaders[0]
loaderTest = dataloaders[2]
with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)
model, optimizer, criterion = my_functions.train_nn(architecture, first_layer, lr, epochs, process, loaderTrain, loaderTest)
from torchvision import datasets, transforms, models
arch = {'vgg16' : 25088,
        'alexnet' : 9216}
if architecture == 'vgg16':
	model = models.vgg16(pretrained=True)
elif architecture == 'alexnet':
	model = models.alexnet(pretrained=True)
model.classifier = nn.Sequential(nn.Linear(arch[architecture], first_layer),
					 nn.ReLU(),
					 nn.Dropout(0.2),
					 nn.Linear(first_layer, 384),
					 nn.ReLU(),
					 nn.Dropout(0.2),
					 nn.Linear(384, 102),
					 nn.LogSoftmax(dim=1))
model.class_to_idx = image_datasets[0].class_to_idx
my_functions.save_checkpoint(path, architecture, first_layer, lr, epochs)
print ('\nTrained NN was saved at {}.'.format(path))